# TODO place all formulas from cpmeasure
