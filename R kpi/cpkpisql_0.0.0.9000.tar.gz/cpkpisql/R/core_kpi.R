# # Combine KPI's into single function call for given connection and inputs
# kpi_label <- read_tsv("src/meta/kpi_labels.tsv")

#' Generate report from axis View
#'
#' @param con DBI connection
#' @param wt_schema Schema for weights (depends on panel)
#' @param purch_schema Schema for purchase data
#' @param period_end Last date of period
#' @param duration How many months before should be used
#' @param positions How many positions from the View should be used
#'
#' @return KPI data.frame (tibble)
#' @export
#'
#' @examples
fetch_kpi_table <- function(con,
                            wt_schema = in_schema("public", "weights"),
                            purch_schema = in_schema("Confectionary", "Confectionary"),
                            period_end = ymd("2024-03-01"),
                            duration = 3,
                            positions = 1:3) {
  # get wave weights
  db_wt <- con |> tbl(wt_schema)
  db_ww <- db_wt |>
    agg_weight_wave(period = period_end, length_in_months = duration) # |>
  # NB: For Query speed up
  # compute()

  # get population
  db_population <- db_ww |>
    group_by(rwbasis) |>
    get_population(weight_wave, projectc)

  # fetch filtered view for purchase data
  period_start <- get_period_before(period_end, duration) |> as.integer()
  period_end <- (period_end %m+% months(1)) |> as.integer()

  db_view <- con |>
    tbl(purch_schema) |>
    # use lower case and extract movedate from occaskey
    rename_all(tolower) |>
    # filter period
    filter(movedate >= period_start,
           movedate < period_end) |>
    filter(position_number %in% positions) |>
    # Add wave weights:
    left_join(db_ww, by = c("hhkey"))

  # Calculate KPIs:
  kpi_df <- db_view |> get_core_kpi(db_population)

  kpi_df
}


#' Export KPI report to XLSX pivot
#'
#' @param kpi_df KPI data frame
#' @param kpi_label Data frame with labels
#' @param path Filename path
#'
#' @return None (export directly to storage)
#' @export
#'
#' @examples
#' kpi_df |> create_xlsx_pivot(kpi_label, "mykpi.xlsx")
create_kpi_pivot <- function(kpi_df, kpi_label, path = NULL) {
  kpi_report <-
    kpi_df |>
    add_derivative_kpi() |>
    kpi_pivot_transform(kpi_label) |>
    select(-name)

  class(kpi_report)  <- c("kpi_report", class(kpi_report))

  kpi_report
}


#' Title
#'
#' @param kpi_df
#' @param kpi_label
#'
#' @return
#' @export
#'
#' @examples
kpi_pivot_transform <- function(kpi_df, kpi_label) {
  kpi_df |>
    pivot_longer(-c(position_number, level, position_name)) |>
    left_join(kpi_label) |>
    # TODO add scale column to labels as requirement, adjust value on the fly
    select(position_number, level, position_name, name, kpi, value)
}

#' S3 method for class `kpi_report`
#'
#' @param wb
#' @param sheet
#' @param data
#' @param ...
#'
#' @return
#' @export
#'
#' @examples
write_data.kpi_report <- function(wb, sheet, data, ...) {
  data <-
    data |>
    mutate_at(vars(value), `class<-`, "comma")
  xlbox:::write_data.data.frame(wb = wb, sheet = sheet, data = data, ...)
}
