
# Population --------------------------------------------------------------

#' Calculate Population RP
#'
#' Population metric depends exclusively on Buyers filter, not purchase behavior.
#' Typically called with `rwbasis` data split, since the RW basis split is required for Buyers RP
#'
#' @param data_total By default uses Total panel DB with weight waves
#' @param weight_wave Weight wave weights (monthly cs weights)
#' @param projectc Projection factor
#' @param scale scale factor (thousands of HH by default)
#'
#' @return Data frame, Population size for each rwbasis group
#' @export
#'
#' @examples
#' db_wt <- con |> tbl(in_schema("public", "pet_weights"))
#' db_ww <- db_wt |>
#'   agg_weight_wave(period = ymd("2024-03-01"), length_in_months = 12) |>
#'   compute()
#' db_ww |>
#'   group_by(rwbasis, .add = TRUE) |>
#'   get_population(weight_wave, projectc)
get_population <- function(data_total, weight_wave, projectc,
                           scale = 1e3, .add = FALSE) {
  population <- data_total |>
    summarise(population = sum({{ weight_wave }} * {{ projectc }}) / scale) |>
    collect()

  return(population)
}

# Volumetric  ------------------------------------------------------------------


#' Volume/Value/Number RP KPI
#'
#' @param db Purchase data DB
#' @param value Value column
#' @param volume Volume column
#' @param number Number column
#' @param rwcompen Product of all factors: brand, category, shop, RW
#' @param fullmasw Full mass weights (monthly cs weights)
#' @param projectf Projection factor
#' @param scale scale scalar (000 default)
#'
#' @return
#' @export
#'
#' @examples
get_volumetric <- function(db, value, volume, number, rwcompen, fullmasw, projectf, scale) {
  db |>
  summarise(
    value       =  sum({{ value }}  * {{ rwcompen }} * {{ fullmasw }}  * {{ projectf }} / {{ scale }}),
    volume_gl   =  sum({{ volume }} * {{ rwcompen }} *  {{ fullmasw }}  * {{ projectf }} / {{ scale }}),
    volume_pack =  sum({{ number }} * {{ rwcompen }} *  {{ fullmasw }}  * {{ projectf }} / {{ scale }})
  ) |>
    collect()
}

# Trips -------------------------------------------------------------------

#' Trips RP calculation
#'
#' @param data Purchase data
#' @param occaskey Trip id (hhkey x movedate x shop)
#' @param rwcompen Product of all factors: brand, category, shop, RW
#' @param fullmasw Full mass weights (monthly cs weights)
#' @param weight_wave Wave weights (mean of monthly CS weights)
#' @param projectf Projection factor
#' @param scale scale factor (thousands of Trips by default)
#' @param .add see `group_by`. TRUE by default
#'
#' @return
#' @export
#'
#' @examples
get_trips <- function(data, occaskey, rwcompen, fullmasw,  weight_wave, projectf, scale = 1e3, .add = TRUE) {
  trips <-
    data |>
    # NB workes for grouped datasets as well
    group_by({{ occaskey}}, .add = .add) |>
    summarise_at(vars({{ projectf }}, {{ rwcompen }}, {{ fullmasw }}, {{ weight_wave}}), mean) |>
    summarise(
      trips_raw = n(),
      trips_wave = sum({{ weight_wave }} * {{ projectf }} / scale),
      trips_fullmass = sum({{ fullmasw }} * {{ rwcompen }} * {{ projectf }} / scale)
    ) |>
    collect()

  return(trips)
}

# Buyers ------------------------------------------------------------------

#' Buyers Wave Weights
#'
#' @param data HH table with wave weights
#' @param hhkey HH key
#' @param weight_wave Weight wave
#' @param projectf Projection factor
#' @param scale scale factor (thousands of Trips by default)
#' @param .add see `group_by`. TRUE by default
#'
#' @return
#' @export
#'
#' @examples
get_buyers_wave <- function(data, hhkey, weight_wave, projectf, scale = 1e3, .add = TRUE) {
  # NB originally the projectf was used.
  # projectc used instead, since it's single value per hhkey
  buyers_wave <- data |>
    # workaround to ensure single value per hhkey
    group_by({{ hhkey }}, .add = .add) |>
    summarise_at(vars({{ weight_wave }}, {{ projectf }}), mean) |>
    # get weight weighted buyers
    summarise(
      buyers_wave = sum({{ weight_wave }} * {{ projectf }} / scale)
    ) |>
    collect()
}

#' Buyers RP
#'
#' @param buyers_wave_rwbasis Buyers Wave Weighted x rwbasis
#' @param trips_rwbasis Trips RP x rwbasis
#' @param population_rwbasis Population RP x rwbasis
#'
#' @return
#' @export
#'
#' @examples
get_buyers_rp <- function(buyers_wave_rwbasis, trips_rwbasis, population_rwbasis) {

  rp_df <- buyers_wave_rwbasis |>
    left_join(trips_rwbasis) |>
    left_join(population_rwbasis, by = join_by(rwbasis))

  buyers_rp <- rp_df |>
    rowwise() |>
    mutate(buyers_rp = cpmeasure:::penetration_correction(
      buyers_wave = buyers_wave,
      trips_raw   = trips_wave,
      trips_rw    = trips_fullmass,
      population  = population
    )) |>
    # switch off rowwise
    group_by(.add = TRUE) |>
    # sum up buyers rp by rwbasis
    summarise_at("buyers_rp", sum)

  buyers_rp
}
