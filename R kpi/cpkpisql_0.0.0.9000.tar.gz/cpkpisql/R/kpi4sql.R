# Weight Wave and population -------------------------------

#' Get previous period
#' Simple function to get period, started `n` months before
#'
#' @param period
#' @param length_in_months
get_period_before <- function(period, length_in_months) {
  period %m-% months(length_in_months - 1)
}

#' Get max value in column
#'
#' @param db
#' @param column
#'
#' @return Max value in column
#' @export
#'
#' @examples
get_max_value <- function(db, column) {
  db |> summarise(across({{ column }}, max)) |> collect() |>  pull(1)
}

#' Title
#'
#' @param weights_total
#' @param period
#' @param length_in_months
#'
#' @return
#' @export
#'
#' @examples
agg_weight_wave <- function(weights_total, period = NULL, length_in_months = 1) {
  # FIXME Expensive!
  if (is.null(period)) {
    period <- get_max_value(weights_total, dt_start)
  }

  # FIXME use these vars to avoid conflicts with tbl colnames
  period_start <- get_period_before(period, length_in_months)
  period_end   <- period

  # get latest rwbasis:
  db_fltd <- weights_total |>
    filter(duration_months == 1,
           between(dt_start, period_start, period_end))

  db_rwbasis_last <-
    db_fltd |>
    group_by(hhkey) |>
    filter(dt_start == max(dt_start)) |>
    select(hhkey, rwbasis)

  # keep only one-month periods:
  db_ww <- db_fltd |>
    group_by(hhkey) |>
    summarise(
      weight_wave = sum(continuo) / length_in_months,
      projectc = mean(projectc)) |>
    left_join(db_rwbasis_last, by = "hhkey")

  db_ww
}

# KPI ---------------------------------------------------------------------


#' Generate KPI table for view
#'
#' @param db_purch
#' @param db_population
#' @param scale
#'
#' @return
#' @export
#'
#' @examples
get_core_kpi <- function(db_purch, db_population, scale = 1e3) {

  # TODO can be calculated directly here?
  population_df <- db_population |> collect()
  population_value = sum(population_df$population)

  # for consitence for various kpi
  db_grouped <- db_purch |>
    group_by(position_number, level, position_name)

  # volumetric:
  kpi_volumetric <- db_grouped |>
    get_volumetric(value = valuetot,
                   volume = volumeto,
                   number = number,
                   rwcompen = rwcompen,
                   fullmasw = fullmasw,
                   projectf = projectf,
                   scale = scale)

  # NB: we'll use rwbasis split for Buyers RP
  kpi_trips_rwbasis <- db_grouped |>
    group_by(rwbasis, .add = TRUE) |>
    get_trips(occaskey = occaskey,
              rwcompen = rwcompen,
              fullmasw = fullmasw,
              weight_wave = weight_wave,
              projectf = projectf,
              scale = scale)

  # Since trips are additive, we can sum them up
  kpi_trips <- kpi_trips_rwbasis |> summarise_if(is.numeric, sum)

  # buyers:
  buyers_wave_rwbasis <- db_grouped |>
    group_by(rwbasis, .add = TRUE) |>
    get_buyers_wave(hhkey = hhkey,
                    weight_wave = weight_wave,
                    projectf = projectf)

  kpi_buyers <- get_buyers_rp(
    buyers_wave_rwbasis = buyers_wave_rwbasis,
    trips_rwbasis = kpi_trips_rwbasis,
    population_rwbasis = population_df
  )

  # value / volume
  kpi_df <-
    kpi_volumetric |>
    left_join(kpi_trips) |>
    left_join(kpi_buyers) |>
    ungroup() |>
    mutate(population = population_value)

  kpi_df |>
    # convert to R numeric format representation
    mutate_if(is.numeric, as.double) |>
    arrange(position_number)
}

add_derivative_kpi <- function(kpi_df, scale = 1e3) {
  kpi_df |>
    rename(buyers = buyers_rp,
           trips = trips_fullmass) |>
    mutate(penetration = buyers / population * 100,
           frequency = trips / buyers) |>
    # derivative KPI
    mutate(
      spend_per_buyer = value / buyers,
      spend_per_trip = value / trips,
      volume_per_buyer_g = volume_gl / buyers / scale,
      volume_per_buyer_pack = volume_pack / buyers,
      volume_per_trip_g = volume_gl / trips / scale, # per kg
      volume_per_trip_pack = volume_pack / trips,
      avg_price_g = value / volume_gl * scale, # per kg
      avg_price_pack = value / volume_pack,
      avg_pack_size = volume_gl / volume_pack / scale
    )
}



# Create selector for period ----------------------------------------------

#' Redefine S3 for ymd to pre-specified integer value
as.integer.Date <- \(x) format(x, "%Y%m%d") |> as.integer()

# set_report_period <- function(period_start, length_in_months = 12) {
#   if (!is.Date(period_start))
#     period_start = ymd(period_start)
#
#   out <- list(
#     period_start = period_start,
#     period_end = period_end,
#     length_in_months = length_in_months
#   )
# }
