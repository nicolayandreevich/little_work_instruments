library(testthat)
library(cpmeasure)

test_check("cpmeasure")
