test_that("penetration rp works", {
  expect_equal(
    pizza_hhinfo %>%
      msr_population(
        weight_wave = weight_wave,
        projectc = projectc
      ) %>%
      round,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Population (000 HH/Ind)"
      ) %>%
      pull(value) %>%
      round)
})

# for penetration correction population_by_rwbasiss is needed:
population_df <- pizza_hhinfo %>%
  group_by(rwbasiss) %>%
  summarise(population = sum(weight_wave * projectc) / 1e3)

test_that("buyers rp works", {
  expect_equal(
    pizza_rawdata %>%
      left_join(pizza_hhinfo %>% select(hhkey, weight_wave, rwbasiss), by = "hhkey") %>%
      msr_buyers(
        hhkey = hhkey,
        occaskey = occaskey,
        rwbasiss = rwbasiss,
        brand_factor = cpoutmar,
        weight_wave = weight_wave,
        weight_fm = fullmasw,
        projectf = projectf,
        population_by_rwbasiss = population_df
      ) %>%
      round,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Buyers (000)"
      ) %>%
      pull(value) %>%
      round)
})

test_that("penetration works", {
  expect_equal(
    msr_penetration(
      buyers = pizza_ait %>%
        filter(
          brand == "TOTAL",
          measure == "Buyers (000)"
        ) %>%
        pull(value),
      population = pizza_ait %>%
        filter(
          brand == "TOTAL",
          measure == "Population (000 HH/Ind)"
        ) %>%
        pull(value)
      ) %>%
      round(1),
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Penetration"
      ) %>%
      pull(value) %>%
      round(1))
})
