test_that("value rp works", {
  expect_equal(
    pizza_rawdata %>%
      msr_value(
        value = wert,
        f_brand = cpoutmar,
        f_rws = cpoutrws,
        f_rwk = cpoutrwk,
        weight_fm = fullmasw,
        projectf = projectf
      ) %>%
      round
    ,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Value (000 EUR)"
      ) %>%
      pull(value) %>%
      round)
})

test_that("volume rp works", {
  expect_equal(
    pizza_rawdata %>%
      msr_volume(
        volume = menge,
        f_brand = cpoutmar,
        f_rws = cpoutrws,
        f_rwk = cpoutrwk,
        weight_fm = fullmasw,
        projectf = projectf
      ) %>%
      round
    ,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Volume (000 L/tonnes)"
      ) %>%
      pull(value) %>%
      round)
})
