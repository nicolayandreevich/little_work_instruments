test_that("trips rp works", {
  expect_equal(
    pizza_rawdata %>%
      msr_trips(
        occaskey   = occaskey,
        weight_rws = cpoutrws,
        weight_fm  = fullmasw,
        projectf   = projectf) %>%
      round,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Trips (000)"
      ) %>%
      pull(value) %>%
      round
  )
})
