test_that("assortment depth rp works", {
  expect_equal(
    pizza_rawdata %>%
      msr_assortment_depth(
        article = artikels
      ) %>%
      round,
    pizza_ait %>%
      filter(
        brand == "TOTAL",
        measure == "Assortment Depth"
      ) %>%
      pull(value) %>%
      round)
})
