# CPmeasure

<!-- badges: start -->

<!-- badges: end -->

The goal of `cpmeasure` is to reproduce AnalyzeIT weighting.

This project at the moment is for educational purposes and can be used as demonstration of how RP weighting done in AIT. Right now it's limited to the German panel only.

## Installation

I cannot find a solution how to install `cpmeasure` with `remotes` package. Therefore, please, use next algorithm:

1.  Go to [Bitbucket Server GfK](https://stash.gfk.com/users/vrkoro/repos/cpmeasure/browse)
2.  Clone the repository to your folder
3.  Open cpmeasure.Rproj in Rstudio
4.  In Rstudio menu and select *Build \> Clean and Rebuild*.

## Available Measures

Basic measures:

| AIT measure             | function             |
|-------------------------|----------------------|
| Value (000 EUR)         | msr_value            |
| Volume (000 L/tonnes)   | msr_volume           |
| Buyers (000)            | msr_buyers           |
| Trips (000)             | msr_trips            |
| Population (000 HH/Ind) | msr_population       |
| Assortment Depth        | msr_assortment_depth |

Bunch of derivative measures available as well.

By default AnalyzeIT provides 75 measusres. You can find description of available measures in [AnalyzeIT Axis Measure help](https://analyze-it.gfk.com/aitprodger/static/C.2.+Axis+Measure+Definition.htm)

There are 3 main classes of AnalyzeIT measures:

-   Basic measures (Volumetric, Buyers, Trips, etc.)
-   Derivative measures (Penetration, Spend per Buyer, etc.)
-   Conditional measures (Frequency Repeaters, Loyalty Trips, Category Spend per Trip, etc.)

Basic measures calculated directly from Raw Data. Derivative measures are calculated from basic measures with formulas.

Conditional measures are special cases of basic or derivative measures, when there is additional condition like frequency class or product fact class needs to be satisfied. Conditional measures can be classified further to basic and derivative.

## Measures calculation

Below you will find basic examples to calculate various RP measures:

### Volumetric

``` r
library(tidyverse)
library(cpmeasure)
    
# value and volume:
pizza_rawdata %>%
  msr_value(
        value = menge,
        f_brand = cpoutmar,
        f_rws = cpoutrws,
        f_rwk = cpoutrwk,
        weight_fm = fullmasw,
        projectf = projectf
      )
      
pizza_rawdata %>%
  msr_volume(
        volume = menge,
        f_brand = cpoutmar,
        f_rws = cpoutrws,
        f_rwk = cpoutrwk,
        weight_fm = fullmasw,
        projectf = projectf
      )
```

### Trips RP

``` r
# Trips RP
pizza_rawdata %>%
  msr_trips(
    occaskey   = occaskey,
    weight_rws = cpoutrws,
    weight_fm  = fullmasw,
    projectf   = projectf
    )

# Trips RP for all brands:    
pizza_rawdata %>%
  group_by(marke) %>%
  nest() %>% 
  mutate(
  trips_rp = map_dbl(data, ~ msr_trips(
    .,
    occaskey   = occaskey,
    weight_rws = cpoutrws,
    weight_fm  = fullmasw,
    projectf   = projectf
    ))
  ) %>% 
  select(brand = marke, trips_rp) %>% 
  arrange(desc(trips_rp))
```

### Buyers RP

Buyers RP is tricky metric for calculation. It requires additional adjustment, i.e. penetration correction. For penetration correction you need to do extra steps:

1.  Calculate HH Wave Weights -- average of **weekly** CS-weights for the whole period
2.  Calculate Population based on buyers and non-buyers for special HH weighting split -- RW_Basiss
3.  Add HH Wave Weights, RW Basiss to purchase data and provide Population by RW Basiss split

Buyers and Penetration calculate for each RW Basiss split and then finally sum up to Buyers (000).

> :warning: Buyers RP is still under development and works only for "good cases". List of known "bad" cases:
>
> -   Capping max population (sum of population \> total population)
> -   Repeat buyers and other buyers classes: 1x, 2x, 3x and etc.
> -   AnalyzeIT special cases (lack of knowledge at the moment)
>
> Therefore **double-check** your calculations!

``` r
# reproduce Wave Weights (already precalculated in pizza_hhinfo):
pizza_hhinfo %>% mutate(weight_wave = rowMeans(across(starts_with("w"))))

# for penetration correction population_by_rwbasiss is needed:
population_df <- pizza_hhinfo %>%
  group_by(rwbasiss) %>%
  summarise(population = sum(weight_wave * projectc) / 1e3)

# buyers
pizza_rawdata %>%
      # add required RW basiss split and Wave Weights:
      left_join(pizza_hhinfo %>% select(hhkey, weight_wave, rwbasiss), by = "hhkey") %>%
      msr_buyers(
        hhkey = hhkey,
        occaskey = occaskey,
        rwbasiss = rwbasiss,
        brand_factor = cpoutmar,
        weight_wave = weight_wave,
        weight_fm = fullmasw,
        projectf = projectf,
        # here we substitute population figures:
        population_by_rwbasiss = population_df
      )
```
