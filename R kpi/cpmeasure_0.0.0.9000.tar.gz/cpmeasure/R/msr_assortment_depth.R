msr_assortment_depth <- function(data, article) {
  assortment_depth <- data %>%
    summarise(assortment_depth = n_distinct({{ article }})) %>%
    pull(assortment_depth)
  return(assortment_depth)
}
