#' Penetration based on population and buyers
#'
#' Penetration = Buyer (000) / Population (000 HH/ind) * 100/
#' Interpretation example:
#'
#' -79,1% of all HH bought the category.
#' Which means that 20,9% of all HH in the panel didn't buy *any* product
#' of the category.
#' - 26,6% of all HH (incl. non buyying HH) bought Brand B
#' - 20,0% bought Brand A in Shop C.
#'
#' @param buyers Buyers RP. Can be calculated with [msr_buyers()]
#' @param population Population RP. Use [msr_population()]
#'
#' @return Penetration
#' @seealso [msr_buyers()], [msr_penetration()]
#' @export
#'
#' @examples
#' msr_penetration(12200, 40864)
msr_penetration <- function(buyers, population) {
  penetration <- buyers / population * 100
  return(penetration)
}


#' Frequency
#'
#' Frequency = Trips (000) / Buyers (000)
#' Interpretation example:
#'
#' - Brand B was bought 2,5 times in Shop A and only at 1,8 times in Shop C.
#' - Frequency is higher in the Total market.
#'
#' @param trips Trips (000). See `msr_trips`.
#' @param buyers Buyers (000). See `msr_buyers`
#'
#' @return Frequency
#' @seealso [msr_trips()], [msr_buyers()]
#' @export
#'
#' @examples
#' msr_frequency(trips = 20970, buyers = 10059)
msr_frequency <- function(trips, buyers) {
  freq <- trips / buyers
  return(freq)
}

#' Spend per Buyer (EUR)
#'
#' Spend per Buyer (EUR) = Value (000 EUR) / Buyer (000)
#' Average expenditures per buyer. Interpretation example:
#' - For Brand A within Shop B the buyers spend on average 19,78 EUR but only 12,00EUR within Shop C.
#'
#' @param value Value (000)
#' @param buyer Buyer (000)
#'
#' @return Spend per Buyer
#' @seealso [msr_value()], [msr_buyers()]
#' @export
#'
#' @examples
#' msr_spend_per_buyer(value = 39411, buyer = 10059)
msr_spend_per_buyer <- function(value, buyer) {
  spend_per_buyer <- value / buyer
  return(spend_per_buyer)
}


#' Spend per Trip (EUR)
#'
#' Spend per Trip (EUR)	= Value (000 EUR) / Trips (000)
#' Interpretation example
#' - The average value per trip of the category was 7,15 EUR.
#' - For Brand A in Shop C this value was 5,59 EUR
#'
#' @param value Value (000 EUR)
#' @param trip Trips (000)
#'
#' @return Spend per Trip
#' @seealso [msr_value()], [msr_trips()]
#' @export
#'
#' @examples
#' msr_spend_per_trip(value = 39411, trip = 20970)
msr_spend_per_trip <- function(value, trip) {
  spend_per_buyer <- value / trip
  return(spend_per_buyer)
}

#' Volume per Buyer
#'
#' Volume per Buyer (L/kg) = Volume (000 L/tonnes) / Buyers (000)
#' Volume per Buyer (Packs) = Volume (000 Packs) / Buyers (000)
#'
#' Interpretation example:
#' - Each buyer bought on average within the category 5,29 Kilogram in the Total market.
#' - 2,75 kilogram of Brand A were sold in average in Shop C, but only 1,36 kilo of Brand B.
#'
#' @param volume Volume (000 L/tonnes) or (000 Packs)
#' @param buyer Buyers (000)
#'
#' @return Volume per Buyer
#' @seealso [msr_volume()], [msr_buyers()]
#' @export
#'
#' @examples
#' msr_volume_per_buyer(volume, buyer)
msr_volume_per_buyer <- function(volume, buyer) {
  vol_per_buyer <- volume / buyer
  return(vol_per_buyer)
}

#' Volume per Trip
#'
#' Volume per Trip (L/kg) = Volume (000 L/tonnes) / Trips (000)
#' Volume per Trip (Packs) = Volume (000 Packs) / Trips (000)
#'
#' Interpretation example:
#' - The average volume per trip for the category was 0,74 kg in the Total market.
#' - In Shop B the average volume per occasion for Brand B was 0,83 kg.
#'
#' @param volume Volume (000 L/tonnes) or (000 Packs)
#' @param trip Trips (000)
#'
#' @return Volume per Trip
#' @seealso [msr_volume()], [msr_trips()]
#' @export
#'
#' @examples
#' msr_volume_per_trip(volume, trip)
msr_volume_per_trip <- function(volume, trip) {
  vol_per_trip <- volume / trip
  return(vol_per_trip)
}

#' Average Price
#'
#' Average Price (EUR/(L/kg)) =	Value (000 EUR) / Volume (000 L/tonnes)
#' Average Price (EUR/Packs) = Value (000 EUR) / Volume (000 Packs)
#' Interpretation example:
#' - The average price per kilogram for Brand C was at EUR 10,29 in Shop A.
#' - One Kilogram of Brand B was at EUR 8,83 in Shop C.
#' - The average price per ""unit"" (Packs) for Brand C is at EUR 4,24 in Shop A.
#' - One ""unit"" (Pack) of Brand B was at EUR 3,61 in Shop C.
#'
#' @param value Value (000 EUR)
#' @param volume Volume (000 L/tonnes) or (000 Packs)
#'
#' @return Average Price
#' @seealso [msr_value()], [msr_volume()]
#' @export
#'
#' @examples
#' msr_avg_price(value = 39411, volume = 8425)
msr_avg_price <- function(value, volume) {
  avg_price <- value / volume
  return(vag_price)
}

#' Average Pack Size (L/kg)
#'
#' Average Pack Size (L/kg) = Volume (000L/tonnes) / Volume (000 Packs)
#' Interpretation example:
#' - The average package size purchased was 0.392 kg in the second period.
#' - Brand A is not sold in Shop A, B or all other shops.
#'
#' @param volume_lkg Volume (000L/tonnes)
#' @param volume_pack Volume (000 Packs)
#'
#' @return Average Pack Size (L/kg)
#' @seealso [msr_volume()]
#' @export
#'
#' @examples
#' msr_avg_packsize(volume_lkg = 8425, volume_pack = 5000)
msr_avg_packsize <- function(volume_lkg, volume_pack) {
  avg_packsize <- volume_lkg / volume_pack
  return(avg_packsize)
}
