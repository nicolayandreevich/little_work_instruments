#' Population RP
#'
#' Population (000 HH/Ind)
#' Distribution of population (abs., total country)
#' The base of all calculation represents the total of all HH / people.
#' This is aligned on a year base. Take note how the population is defined
#' such as (which age groups are incl. / are foreigners incl. etc).
#'
#' Requires special precalculated Wave Weights, which is avg. of weekly weights (DE)
#'
#' @param data Raw data inc. non-buyers
#' @param weight_wave Wave weights -- avg. of weekly weights
#' @param projectc Continuous projection factor
#'
#' @return Population RP
#' @export
#'
#' @examples
#' pizza_hhinfo %>%
#' msr_population(
#'   weight_wave = weight_wave,
#'   projectc = projectc
#' )
msr_population <- function(data, weight_wave, projectc) {
  population <- data %>%
    summarise(population = sum({{ weight_wave }} * {{ projectc }}) / 1e3) %>%
    pull(population)

  return(population)
}


#' Probabilty of non-buyer
p_nonbuyer <- function(m, k) {(1 + m / k) ^ (-k)}

#' Find k for non-buyers for given p0 and m
find_k <- function(p0, m, interval = c(0, 100)) {
  k <- optimise(function(p0, m, k) (p_nonbuyer(m, k) - p0)^2, interval, m = m, p0 = p0)
  return(k$minimum)
}

#' Penetration correction function:
penetration_correction <- function(buyers_wave, trips_raw, trips_rw, population = 40863.8, interval = c(0, 100)) {
  # FIXME: border cases when p0 == 0 or 1 shall be covered!
  # FIXME: add p0 < 0 and p0 > 1 checks!
  p0 = 1 - buyers_wave / population
  m  = trips_raw / population

  k = find_k(p0 = p0, m = m, interval = interval)
  m2 = trips_rw / population
  p0_2 = p_nonbuyer(m = m2, k = k)
  buyer_rp = population * (1 - p0_2)

  return(buyer_rp)
}

#' Buyers RP
#'
#' Buyers (000) = Penetration  * Population (000 HH/Ind). It's the absolute amount
#'  of buyers in the Total market. Interpretation example:
#'  "This category was bought by 31,395 mio. households.
#'  The structure is the same as for Buyer Share.
#'
#' @param data Raw Data
#' @param hhkey Household key
#' @param occaskey Trips id / occasion key
#' @param rwbasiss Response weight households groups. Required for RP.
#' @param brand_factor Brand factor
#' @param weight_wave Weight weighting (avg. across **weekly** weights DE panel)
#' @param weight_fm Full mass weight
#' @param projectf Projection factor
#' @param population_by_rwbasiss Data frame Population by RW-basis HH-groups.
#' Must be calculated for both buyers + non-buyers.
#'
#' @return Buyers RP
#' @export
#'
#' @examples
#' pizza_rawdata %>%
#' left_join(pizza_hhinfo %>% select(hhkey, weight_wave), by = "hhkey") %>%
#'   msr_buyers(
#'     hhkey = hhkey,
#'     occaskey = occaskey,
#'     brand_factor = cpoutmar,
#'     weight_wave = weight_wave,
#'     weight_fm = fullmasw,
#'     projectf = projectf
#'   )
msr_buyers <- function(data, hhkey, rwbasiss, occaskey, brand_factor,
                       weight_wave, weight_fm, projectf, population_by_rwbasiss) {
  # Penetration Correction requires avg. buyers and trips, fullmass trips and population
  trips_df <- data %>%
    group_by({{ rwbasiss }}, {{ hhkey }}, {{ occaskey }},
             {{ weight_wave }}, {{ projectf }}, {{ weight_fm }}) %>%
    summarise(avg_rw = mean({{ brand_factor }})) %>%
    ungroup

  # calculate trips on HH level:
  hh_df <- trips_df %>%
    group_by({{ rwbasiss }}, {{ hhkey }}, {{ weight_wave }}, {{ projectf }}) %>%
    summarise(
      trips_raw = n_distinct({{ occaskey }}),
      trips_rw = sum(avg_rw * {{ weight_fm }})
    ) %>%
    ungroup

  # summarize
  rp_df <- hh_df %>%
    mutate(across({{ projectf }}, ~ . / 1e3)) %>%
    group_by({{ rwbasiss }}) %>%
    summarise(
      buyers_wave = sum({{ weight_wave }} * {{ projectf }}),
      trips_wave  = sum(trips_raw * {{ weight_wave }} * {{ projectf }}),
      trips_fs   = sum(trips_rw * {{ projectf }})
    ) %>%
    # FIXME! add various checks for compatibility:
    # FIXME! penetration
    left_join(population_by_rwbasiss, by = rlang::as_name(rlang::enquo(rwbasiss)))

  buyers_rp <- rp_df %>%
    rowwise() %>%
    mutate(buyers_rp = penetration_correction(
      buyers_wave = buyers_wave,
      trips_raw   = trips_wave,
      trips_rw    = trips_fs,
      population  = population
    )) %>%
    ungroup %>%
    summarise_at("buyers_rp", sum) %>%
    pull(buyers_rp)

  return(buyers_rp)
}
