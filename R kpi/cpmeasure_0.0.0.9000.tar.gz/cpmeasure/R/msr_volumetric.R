#' Value RP calculation
#'
#' Value. Interpretation examples:
#' - The Total market value was 1.606.755,5 € (000).
#' - Brand C achieves a value of 333.033,2 tsd. € in the total market.
#' - Shop A is by market value the most important channel for Brand C.
#'
#' @param data Raw data
#' @param value Value
#' @param f_brand Brand factor
#' @param f_rws Response Weight Shops factor
#' @param f_rwk Response Weight correction factor
#' @param weight_fm Full mass weight
#' @param projectf Projection factor
#'
#' @return Value (000 EUR)
#' @export
#'
#' @examples
#' pizza_rawdata %>%
#' msr_value(
#'   value = menge,
#'   f_brand = cpoutmar,
#'   f_rws = cpoutrws,
#'   f_rwk = cpoutrwk,
#'   weight_fm = fullmasw,
#'   projectf = projectf
#' )

msr_value <- function(data, value, f_brand, f_rws, f_rwk, weight_fm, projectf) {
  value <- data %>%
    summarise(
      value = sum({{ value }} * {{ f_brand }} * {{ f_rws }} * {{ f_rwk }} *
                    {{ weight_fm }}  * {{ projectf }}) / 1e5
    ) %>%
    pull(value)

  return(value)
  # return(14592)
}

#' Volume RP calculation
#'
#' Volume (000 L/tonnes). Interpretation example:
#' - Total market 166.157,1 tons of the category were sold.
#' - Brand C sold 32.809,8 tons in the Total market.
#' - On this quantity basis Shop A is the most important sales channel for Brand C.
#'
#' @param data Raw data
#' @param volume Volume
#' @param f_brand Brand factor
#' @param f_rws Response Weight Shops factor
#' @param f_rwk Response Weight correction factor
#' @param weight_fm Full mass weight
#' @param projectf Projection factor
#'
#' @return Volume (000 L/tonnes) RP
#' @export
#'
#' @examples
#' pizza_rawdata %>%
#' msr_volume(
#'   volume = menge,
#'   f_brand = cpoutmar,
#'   f_rws = cpoutrws,
#'   f_rwk = cpoutrwk,
#'   weight_fm = fullmasw,
#'   projectf = projectf
#' )
msr_volume <- function(data, volume, f_brand, f_rws, f_rwk, weight_fm, projectf) {
  volume <- data %>%
    summarise(
      volume = sum({{ volume }} * {{ f_brand }} * {{ f_rws }} * {{ f_rwk }} *
                    {{ weight_fm }}  * {{ projectf }}) / 1e6
    ) %>%
    pull(volume)

  return(volume)
}
