#' Trips RP calculation
#'
#' Trips (000) are all trips within a category or for a brand in Total market or a specific shop.
#'
#' @param data Raw data
#' @param occaskey Trip/occasion id
#' @param weight_rws Response weight for shop
#' @param weight_fm Full mass weight
#' @param projectf Projection factor
#'
#' @return Trips RP
#' @export
#' @import dplyr
#'
#' @examples
#' library(tidyverse)
#' pizza_rawdata %>%
#' msr_trips(
#'   occaskey   = occaskey,
#'   weight_rws = cpoutrws,
#'   weight_fm  = fullmasw,
#'   projectf   = projectf
#'   )
#'
msr_trips <- function(data, occaskey, weight_rws, weight_fm, projectf) {
  trips_wt <- data %>%
    group_by({{ occaskey }}) %>%
    summarise(trips_rw = mean({{ weight_rws }}))

  trips <-
    data %>%
    distinct({{ occaskey}}, {{ projectf }}, {{ weight_fm }}) %>%
    # FIXME! is this by NSE that complicated??
    left_join(trips_wt, by = rlang::as_name(rlang::enquo(occaskey))) %>%
    summarise(trips_rp = sum(trips_rw * {{ weight_fm }} * {{ projectf }} / 1e3)) %>%
    pull(trips_rp)

  return(trips)
}

